<div class="meta_single">
	<span class="author"><i class="icon_meta icon_author"></i>Tác giả: <b><?php the_author();?></b></span>
	<span class="date"><i class="icon_meta icon_date"></i><?php the_time('d'); ?> tháng <?php the_time('m'); ?>, <?php the_time('Y'); ?></span>
</div>