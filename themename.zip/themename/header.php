<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
	<head>
		<meta charset="UTF-8">
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<?php wp_head(); ?>
		<?php if(get_option('origin-favicon')){ ?>
		<link rel="shortcut icon" href="<?php echo get_option('origin-favicon');?>" type="image/x-icon">
		<?php }?>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.carousel.css">
		<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.0.0/css/all.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/style.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css">
		<script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
		<?php the_field('code_header','option')?>
	</head>
	<body <?php body_class(); ?>>
		<?php the_field('code_body','option')?>
		<header id="header">
			<?php if (is_home() || is_front_page()) { ?>
			<h1 class="sitename" style="display: none;"><?php bloginfo('title'); ?></h1>
			<?php } ?>
			<div class="header_pc">
				<div class="container">
					<div class="row flex flex-center">
						<div class="col-md-2">
							<div class="header_logo">
								<div class="logo"><a href="<?php bloginfo('home');?>" title="<?php bloginfo('title'); ?>"><img src="<?php the_field('logo','option') ?>" alt="<?php bloginfo('title');?>"/></a></div>
							</div>
						</div>
						<div class="col-md-10">
							<nav class="header_menu">
								<?php wp_nav_menu( array( 'container' => '','theme_location' => 'main','menu_class' => 'menu clearfix' ) ); ?>
							</nav>
						</div>
					</div>
				</div>
			</div>
			<div class="header_mb">
				<div class="header_main_mb">
					<div class="container">
						<div class="flex flex-center">
							<div class="logo_mb">
								<div class="logo"><a href="<?php bloginfo('home');?>" title="<?php bloginfo('title'); ?>"><img src="<?php the_field('logo','option') ?>" alt="<?php bloginfo('title');?>"/></a></div>
							</div>
							<div id="touch_menu" class="touch_menu">
								<span class="line"></span>
							</div>
						</div>
					</div>
				</div>
				
				<div id="menu_bar_mobile">
					<?php wp_nav_menu( array( 'container' => '','theme_location' => 'main','menu_class' => 'menu_mobile clearfix' ) ); ?>
				</div>
				<div class="bg_dark"></div>
			</div>
		</header>