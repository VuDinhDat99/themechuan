<?php get_header();wp_reset_query();  $format = get_post_format();?>
<?php $term_list = wp_get_post_terms($post->ID, 'category', array("fields" => "ids"));$a=$post->ID; ?>
<main id="main">
    <?php get_template_part('breadcrums'); ?>
    <div id="content_pages">
        <div class="container">
            <?php if($format=='aside' ){ ?>
            
            <?php }elseif($format=='chat' ){ ?>

            <?php }else{ ?>
            <div class="all_box">
                <div class="row">
                    <div class="col-md-9">
                        <?php while (have_posts()) : the_post(); setPostViews($post->ID);?>
                        <h1 class="title_single"><?php the_title();?></h1>
                        <?php get_template_part('meta'); ?>
                        <div class="entry_content">
                            <div class="content-post clearfix">
                                <?php the_content(); ?>
                            </div>
                        </div>
                        <div class="tagged_as clearfix">
                        <?php the_tags( '<span><i class="fa fa-tags" aria-hidden="true"></i> Tags: </span> ', ' '); ?>
                        </div>
                        <?php endwhile; ?>
                        <div class="related-posts">
                            <div class="title">Bài viết liên quan</div>
                            <?php
                            $categories = get_the_category(get_the_ID());
                            if ($categories){
                            
                            $category_ids = array();
                            foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
                            $args=array(
                            'category__in' => $category_ids,
                            'post__not_in' => array(get_the_ID()),
                            'posts_per_page' => 3,
                            );
                            $my_query = new wp_query($args);
                            if( $my_query->have_posts() ):
                            echo '<div class="sidebar flex">';
                            while ($my_query->have_posts()):$my_query->the_post();
                            ?>
                            <div class="item single-post">
                                <div class="img">
                                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
                                </div>
                                <div class="info">
                                    <h3 class="capt"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <div class="date"><img src="<?php bloginfo('template_url' ); ?>/images/icon_date.png" alt=""><?php the_time('d.m.Y'); ?></div>
                                </div>
                            </div>
                            <?php
                            endwhile;
                            echo '</div>';
                            endif; wp_reset_query();
                            }
                            ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="sidebar">
                            <?php get_template_part('sidebar'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</main>
<?php get_footer(); ?>