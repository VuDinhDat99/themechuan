<article class="item_post">
	<div class="thumb">
		<a href="<?php the_permalink()?>"><?php the_post_thumbnail('large', array('class' => '')); ?></a>
	</div>
	<div class="cnt">
		<h3><a href="<?php the_permalink()?>"><?php the_title(); ?></a></h3>
		<p><?php echo wp_trim_words( get_the_content(), 30, '...' ); ?></p>
	</div>
</article>