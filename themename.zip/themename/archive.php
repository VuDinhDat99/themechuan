<?php get_header(); $a=get_query_var('cat' );?>
<?php $term = get_queried_object(); ?>
<main id="main">
    <?php get_template_part('breadcrums'); ?>
    <div id="content_pages">
        <div class="container">
            <?php if(get_field( 'loai', 'category_'.$a)==3){ ?>
            <?php }elseif(get_field( 'loai', 'category_'.$a)==2){ ?>
            
            <?php }else{ ?>
            <div class="all_box">
                <h1><?php echo single_cat_title();?></h1>
                <?php if (category_description( $category )) : ?>
                <div class="category-info"><?php echo category_description( $category ); ?></div>
                <?php endif ?>
                <div class="row">
                    <div class=" col-md-12">
                        <div class="list_news">
                            <?php if(have_posts()){ while(have_posts()):the_post();$format=get_post_format();setPostViews($post->ID); ?>
                            <?php get_template_part('loop'); ?>
                            <?php endwhile;wp_reset_postdata(); ?>
                            <?php }?>
                        </div>
                        <?php get_template_part( 'pagination' ); ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</main>
<?php get_footer(); ?>