<form role="search" action="<?php echo home_url( '/' ); ?>" method="get" class="searchform clearfix">
	<input type="text" name="s" class="search-input" placeholder="Tìm kiếm ...">
	<button type="submit" class="submit-input"><i class="fas fa-search"></i></button>
</form>