<div class="meta">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" />
	<i class="fa fa-clock-o" aria-hidden="true"></i> <?php the_time('d/m/Y') ?>
	<i class="fa fa-user" aria-hidden="true"></i> <?php the_author() ?>
	<i class="fa fa-commenting-o" aria-hidden="true"></i> <?php comments_popup_link('0 bình luận', '1 bình luận', '% bình luận', 'comments-link', ''); ?>
</div>