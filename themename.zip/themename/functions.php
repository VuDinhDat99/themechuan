<?php

// Remove update notifications
function vutruso_remove_update_notifications( $value ) {

    if ( isset( $value ) && is_object( $value ) ) {
        unset( $value->response[ 'advanced-custom-fields-pro/acf.php' ] );
    }

    return $value;
}
add_filter( 'site_transient_update_plugins', 'vutruso_remove_update_notifications' );

// Them thumbnail cho post & page
 /* === Add Thumbnails to Posts/Pages List === */
if ( !function_exists('o99_add_thumbs_column_2_list') && function_exists('add_theme_support') ) {

    //  // set your post types , here it is post and page...
    add_theme_support('post-thumbnails', array( 'post', 'page' ) );

    function o99_add_thumbs_column_2_list($cols) {

        $cols['thumbnail'] = __('Thumbnail');

        return $cols;
    }

    function o99_add_thumbs_2_column($column_name, $post_id) {

            $w = (int) 60;
            $h = (int) 60;

            if ( 'thumbnail' == $column_name ) {
                // back comp x WP 2.9
                $thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
                // from gal
                $attachments = get_children( array('post_parent' => $post_id, 'post_type' => 'attachment', 'post_mime_type' => 'image') );
                if ($thumbnail_id)
                    $thumb = wp_get_attachment_image( $thumbnail_id, array($w, $h), true );
                elseif ($attachments) {
                    foreach ( $attachments as $attachment_id => $attachment ) {
                        $thumb = wp_get_attachment_image( $attachment_id, array($w, $h), true );
                    }
                }
                    if ( isset($thumb) && $thumb ) {
                        echo $thumb;
                    } else {
                        echo __('None');
                    }
            }
    }

    // for posts
    add_filter( 'manage_posts_columns', 'o99_add_thumbs_column_2_list' );
    add_action( 'manage_posts_custom_column', 'o99_add_thumbs_2_column', 10, 2 );

    // for pages
    add_filter( 'manage_pages_columns', 'o99_add_thumbs_column_2_list' );
    add_action( 'manage_pages_custom_column', 'o99_add_thumbs_2_column', 10, 2 );
}

/*=============================================
                BREADCRUMBS
=============================================*/
//  to include in functions.php
function the_breadcrumb()
{
    $showOnHome = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
    $delimiter = '<span class="separator"><i class="fa-light fa-angle-right"></i></span>'; // delimiter between crumbs
    $home = 'Home'; // text for the 'Home' link
    $showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
    $before = '<span class="current">'; // tag before the current crumb
    $after = '</span>'; // tag after the current crumb

    global $post;
    $homeLink = get_bloginfo('url');
    if (is_home() || is_front_page()) {
        if ($showOnHome == 1) {
            echo '<div id="breadcrumbs" class="breadcrumbs"><a href="' . $homeLink . '">' . $home . '</a></div>';
        }
    } else {
        echo '<div id="breadcrumbs" class="breadcrumbs"><a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' ';
        if (is_category()) {
            $thisCat = get_category(get_query_var('cat'), false);
            if ($thisCat->parent != 0) {
                echo get_category_parents($thisCat->parent, true, ' ' . $delimiter . ' ');
            }
            echo $before . '' . single_cat_title('', false) . '' . $after;
        } elseif (is_search()) {
            echo $before . 'Search results for "' . get_search_query() . '"' . $after;
        } elseif (is_day()) {
            echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
            echo '<a href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
            echo $before . get_the_time('d') . $after;
        } elseif (is_month()) {
            echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
            echo $before . get_the_time('F') . $after;
        } elseif (is_year()) {
            echo $before . get_the_time('Y') . $after;
        } elseif (is_single() && !is_attachment()) {
            if (get_post_type() != 'post') {
                $post_type = get_post_type_object(get_post_type());
                $slug = $post_type->rewrite;
                echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a>';
                if ($showCurrent == 1) {
                    echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
                }
            } else {
                $cat = get_the_category();
                $cat = $cat[0];
                $cats = get_category_parents($cat, true, ' ' . $delimiter . ' ');
                if ($showCurrent == 0) {
                    $cats = preg_replace("#^(.+)\s$delimiter\s$#", "$1", $cats);
                }
                echo $cats;
                if ($showCurrent == 1) {
                    echo $before . get_the_title() . $after;
                }
            }
        } elseif (!is_single() && !is_page() && get_post_type() != 'post' && !is_404()) {
            $post_type = get_post_type_object(get_post_type());
            echo $before . $post_type->labels->singular_name . $after;
        } elseif (is_attachment()) {
            $parent = get_post($post->post_parent);
            $cat = get_the_category($parent->ID);
            $cat = $cat[0];
            echo get_category_parents($cat, true, ' ' . $delimiter . ' ');
            echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a>';
            if ($showCurrent == 1) {
                echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
            }
        } elseif (is_page() && !$post->post_parent) {
            if ($showCurrent == 1) {
                echo $before . get_the_title() . $after;
            }
        } elseif (is_page() && $post->post_parent) {
            $parent_id  = $post->post_parent;
            $breadcrumbs = array();
            while ($parent_id) {
                $page = get_page($parent_id);
                $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
                $parent_id  = $page->post_parent;
            }
            $breadcrumbs = array_reverse($breadcrumbs);
            for ($i = 0; $i < count($breadcrumbs); $i++) {
                echo $breadcrumbs[$i];
                if ($i != count($breadcrumbs)-1) {
                    echo ' ' . $delimiter . ' ';
                }
            }
            if ($showCurrent == 1) {
                echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
            }
        } elseif (is_tag()) {
            echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after;
        } elseif (is_author()) {
            global $author;
            $userdata = get_userdata($author);
            echo $before . 'Articles posted by ' . $userdata->display_name . $after;
        } elseif (is_404()) {
            echo $before . 'Error 404' . $after;
        }
        if (get_query_var('paged')) {
            if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
                echo ' (';
            }
            echo __('Page') . ' ' . get_query_var('paged');
            if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
                echo ')';
            }
        }
        echo '</div>';
    }
} // end the_breadcrumb()



function bootstrap_pagination( \WP_Query $wp_query = null, $echo = true, $params = [] ) {
    if ( null === $wp_query ) {
        global $wp_query;
    }

    $add_args = [];

    //add query (GET) parameters to generated page URLs
    if (isset($_GET[ 'sort' ])) {
        $add_args[ 'sort' ] = (string)$_GET[ 'sort' ];
    }

    $pages = paginate_links( array_merge( [
            'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
            'format'       => '?paged=%#%',
            'current'      => max( 1, get_query_var( 'paged' ) ),
            'total'        => $wp_query->max_num_pages,
            'type'         => 'array',
            'show_all'     => false,
            'end_size'     => 1,
            'mid_size'     => 2,
            'prev_next'    => true,
            'prev_text'    => __( '«' ),
            'next_text'    => __( '»' ),
            'add_args'     => $add_args,
            'add_fragment' => ''
        ], $params )
    );

    if ( is_array( $pages ) ) {
        //$current_page = ( get_query_var( 'paged' ) == 0 ) ? 1 : get_query_var( 'paged' );
        $pagination = '<nav class="navigation pagination"><nav class="nav-links"><ul class="page-numbers">';

        foreach ( $pages as $page ) {
            $pagination .= '<li> ' . $page . '</li>';
        }

        $pagination .= '</ul></nav></nav>';

        if ( $echo ) {
            echo $pagination;
        } else {
            return $pagination;
        }
    }

    return null;
}

// Webpp
function webp_upload_mimes($existing_mimes) {
    $existing_mimes['webp'] = 'image/webp';
    return $existing_mimes;
}
add_filter('mime_types', 'webp_upload_mimes');

add_filter( 'upload_mimes', 'custom_mime_types', 1, 1 );
function custom_mime_types( $mime_types ) {
$mime_types['jfif'] = 'image/jfif+xml'; // Adding .jfif extension

return $mime_types;
}

//** * Enable preview / thumbnail for webp image files.*/
function webp_is_displayable($result, $path) {
    if ($result === false) {
        $displayable_image_types = array( IMAGETYPE_WEBP );
        $info = @getimagesize( $path );

        if (empty($info)) {
            $result = false;
        } elseif (!in_array($info[2], $displayable_image_types)) {
            $result = false;
        } else {
            $result = true;
        }
    }

    return $result;
}
add_filter('file_is_displayable_image', 'webp_is_displayable', 10, 2);

// Disables the block editor from managing widgets in the Gutenberg plugin.
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );
// Disables the block editor from managing widgets.
add_filter( 'use_widgets_block_editor', '__return_false' );

function filter_ptags_on_images($content){
    return preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content);
}
add_filter('the_content', 'filter_ptags_on_images');

register_nav_menu( 'main', 'Main' );
register_sidebar( array(
    'name'          => __( 'Footer', 'theme_text_domain' ),
    'id'            => 'footer',
    'description'   => '',
    'class'         => '',
    'before_widget' => '<div id="%1s" class="widget %2s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="footer-title">',
    'after_title'   => '</div>'
) );

register_sidebar( array(
    'name'          => __( 'Sidebar', 'theme_text_domain' ),
    'id'            => 'sidebar',
    'description'   => '',
    'class'         => '',
    'before_widget' => '<div id="%1s" class="widget %2s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="sidebar-title">',
    'after_title'   => '</div>'
) );

//Đưa trình soạn thảo WordPress 5.0 về phiên bản cũ không dùng plugin  
add_filter('use_block_editor_for_post', '__return_false');

function rename_post_formats( $safe_text ) {
    if ( $safe_text == 'Đứng riêng' )
    return 'Sản phẩm';
    if ( $safe_text == 'Chat' )
    return 'Hỏi đáp';
    if ( $safe_text == 'Chuẩn' )
    return 'Tin tức';
    return $safe_text;
    }
    add_filter( 'esc_html', 'rename_post_formats' );
    add_theme_support( 'post-formats', array( 'aside' ,'chat') );


class home_xn extends WP_Widget {
function home_xn(){
parent::WP_Widget('home_xn',
'Xem nhiều',
array('description' => ''));
}
function widget( $args, $instance ) {
extract($args);
$title = apply_filters( 'widget_title',
empty($instance['title']) ? '' : $instance['title'],
$instance, $this->id_base);
$sp = apply_filters( 'widget_text', $instance['sp'], $instance );
echo $before_widget;
?>

<div class="sidebar-title"><a href="#"><?php echo ($title);?></a></div>
<div class="widget-content">
    <?php $new=new WP_Query('showposts=5&meta_key=post_views_count&orderby=meta_value_num&order=DESC');while($new->have_posts()) : $new->the_post();?>
    <div class="single-post">
        <div class="img">
            <a href="<?php the_permalink();?>"><?php the_post_thumbnail('large');?></a>
        </div>
        <div class="info">
            <h4 class="capt"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
            <div class="date"><img src="<?php bloginfo('template_url' ); ?>/images/icon_date.png" alt=""><?php the_time('d.m.Y'); ?></div>
        </div>
    </div>
    <?php endwhile;?>
</div>



<?php
echo $after_widget;
}
function update( $new_instance, $old_instance ) {
$instance = $old_instance;
$instance['title'] = strip_tags($new_instance['title']);
$instance['sp'] =  $new_instance['sp'];

return $instance;
}
function form( $instance ) {
$instance = wp_parse_args( (array) $instance,
array( 'title' => '', 'sp' => '' ) );
$title = strip_tags($instance['title']);
$sp = ($instance['sp']);

?>
<p>
    <label for="<?php echo $this->get_field_id('title'); ?>">
    <?php _e('Tiêu đề :'); ?> </label>
    <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
    name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title?>" />
</p>



<?php
}
}
register_widget('home_xn');
class home_news extends WP_Widget {
function home_news(){
parent::WP_Widget('home_news',
'Tin mới',
array('description' => ''));
}
function widget( $args, $instance ) {
extract($args);
$title = apply_filters( 'widget_title',
empty($instance['title']) ? '' : $instance['title'],
$instance, $this->id_base);
$sp = apply_filters( 'widget_text', $instance['sp'], $instance );
echo $before_widget;
?>

<div class="sidebar-title"><?php echo ($title);?></div>
<div class="widget-content">
    
    <?php $new=new WP_Query('showposts=5&orderby=date&order=DESC');while($new->have_posts()) : $new->the_post();?>
    <div class="single-post">
        <div class="img">
            <a href="<?php the_permalink();?>"><?php the_post_thumbnail('large');?></a>
        </div>
        <div class="info">
            <h4 class="capt"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
            <div class="date"><img src="<?php bloginfo('template_url' ); ?>/images/icon_date.png" alt=""><?php the_time('d.m.Y'); ?></div>
        </div>
    </div>
    <?php endwhile;?>
    
</div>



<?php
echo $after_widget;
}
function update( $new_instance, $old_instance ) {
$instance = $old_instance;
$instance['title'] = strip_tags($new_instance['title']);
$instance['sp'] =  $new_instance['sp'];

return $instance;
}
function form( $instance ) {
$instance = wp_parse_args( (array) $instance,
array( 'title' => '', 'sp' => '' ) );
$title = strip_tags($instance['title']);
$sp = ($instance['sp']);

?>
<p>
    <label for="<?php echo $this->get_field_id('title'); ?>">
    <?php _e('Tiêu đề :'); ?> </label>
    <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
    name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title?>" />
</p>



<?php
}
}
register_widget('home_news');


 class Home_style_55 extends WP_Widget {
function Home_style_55(){
parent::WP_Widget('Home_style_55',
'Tin tức sidebar',
array('description' => ''));
}
function widget( $args, $instance ) {
extract($args);
$title = apply_filters( 'widget_title',empty($instance['title']) ? '' : $instance['title'],$instance, $this->id_base);
$sp = apply_filters( 'widget_text', $instance['sp'], $instance );
$sl = apply_filters( 'widget_text', $instance['sl'], $instance );
echo $before_widget;
?>
<div class="sidebar-title"><?php echo get_cat_name($sp ); ?></div>
<div class="widget-content">
    <?php $new=new WP_Query('showposts='.$sl.'&cat='.$sp);
    while($new->have_posts()) : $new->the_post();  ?>
    <div class="single-post">
        <div class="img">
            <a href="<?php the_permalink();?>"><?php the_post_thumbnail('large');?></a>
        </div>
        <div class="info">
            <h4 class="capt"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
            <div class="date"><img src="<?php bloginfo('template_url' ); ?>/images/icon_date.png" alt=""><?php the_time('d.m.Y'); ?></div>
        </div>
    </div>
    <?php endwhile;?>
</div>
<?php
echo $after_widget;
}
function update( $new_instance, $old_instance ) {
$instance = $old_instance;
$instance['title'] = strip_tags($new_instance['title']);
$instance['sp'] =  $new_instance['sp'];
$instance['sl'] =  $new_instance['sl'];
return $instance;
}
function form( $instance ) {
$instance = wp_parse_args( (array) $instance,
array( 'title' => '', 'sp' => '', 'sl' => '' ) );
$title = strip_tags($instance['title']);
$sp = ($instance['sp']);$sl = ($instance['sl']);
?>
<p>
    <label for="<?php echo $this->get_field_id('title'); ?>">
    <?php _e('Tiêu đề :'); ?> </label>
    <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
    name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo  get_cat_name($sp);?>" />
</p>
<p>
    <label for="<?php echo $this->get_field_id('sp'); ?>">
    <?php _e('Id Chuyên Mục.'); ?> </label>
    <select name="<?php echo $this->get_field_name('sp'); ?>" id="<?php echo $this->get_field_id('sp'); ?>">
        <?php $args = array(
        'orderby' => 'name','hide_empty'=>0,
        'order' => 'ASC'
        );$categories=get_categories( $args ); foreach($categories as $category) {?>
        <option value="<?php echo $category->term_id; ?>" <?php if($category->term_id ==$sp){echo 'selected="selected"';} ?>><?php echo $category->cat_name; ?></option>
        
        <?php } ?>
    </select>
</p>
<p>
    <label for="<?php echo $this->get_field_id('sl'); ?>">
    <?php _e('Số Lượng :'); ?> </label>
    <input class="widefat" id="<?php echo $this->get_field_id('sl'); ?>"
    name="<?php echo $this->get_field_name('sl'); ?>" type="number" value="<?php echo  $sl;?>" />
</p>
<?php
}
}
register_widget('Home_style_55');


add_filter( 'widget_text', 'do_shortcode' );

function crunchify_remove_version() {
    return '';
}
add_filter('the_generator', 'crunchify_remove_version');

remove_action('wp_head', 'rest_output_link_wp_head', 10);
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
remove_action('template_redirect', 'rest_output_link_header', 11, 0);

remove_action ('wp_head', 'rsd_link');
remove_action( 'wp_head', 'wlwmanifest_link');
remove_action( 'wp_head', 'wp_shortlink_wp_head');

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
function catch_that_image() {
global $post, $posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
$first_img = $matches [1] [0];
if(empty($first_img)){ //Defines a default image
$first_img = "/images/default.jpg"; //Duong dan anh mac dinh khi khong tim duoc anh dai dien
}
return $first_img;
}
if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
                'page_title'    => 'Theme General Settings',
                'menu_title'    => 'Quản Lý Trang',
                'menu_slug'     => 'theme-general-settings',
                'capability'    => 'manage_options',
                        'redirect'      => false
    ));
    };
    
        
   
   add_theme_support('post-thumbnails');

    function remove_default_widgets() {
    unregister_widget('WP_Widget_Pages');
    unregister_widget('WP_Widget_Calendar');
    unregister_widget('WP_Widget_Archives');
    unregister_widget('WP_Widget_Links');
    unregister_widget('WP_Widget_Meta');
    unregister_widget('WP_Widget_RSS');
    unregister_widget('WP_Widget_Tag_Cloud');
    }

   //Đếm số lượt xem

    function getPostViews($postID){ // hàm này dùng để lấy số người đã xem qua bài viết
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){ // Nếu như lượt xem không có
    delete_post_meta($postID, $count_key);
    add_post_meta($postID, $count_key, '0');
    return "0"; // giá trị trả về bằng 0
    }
    return $count; // Trả về giá trị lượt xem
    }
    function setPostViews($postID) {// hàm này dùng để set và update số lượt người xem bài viết.
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
    $count = 0;
    delete_post_meta($postID, $count_key);
    add_post_meta($postID, $count_key, '0');
    }else{
    $count++; // cộng đồn view
    update_post_meta($postID, $count_key, $count); // update count
    }
    }

//Ẩn WordPress Version
function wpb_remove_version() {
return '';
}
add_filter('the_generator', 'wpb_remove_version');



//Vô hiệu hóa XML-RPC trong WordPress
add_filter('xmlrpc_enabled', '__return_false');

//Bảo vệ WordPress khỏi các truy vấn nguy hiểm
global $user_ID; if($user_ID) {
        if(!current_user_can('administrator')) {
                if (strlen($_SERVER['REQUEST_URI']) > 255 ||
                        stripos($_SERVER['REQUEST_URI'], "eval(") ||
                        stripos($_SERVER['REQUEST_URI'], "CONCAT") ||
                        stripos($_SERVER['REQUEST_URI'], "UNION+SELECT") ||
                        stripos($_SERVER['REQUEST_URI'], "base64")) {
                                @header("HTTP/1.1 414 Request-URI Too Long");
                                @header("Status: 414 Request-URI Too Long");
                                @header("Connection: Close");
                                @exit;
                }
        }
}

function wp_nav_menu_no_ul()
{
    $options = array(
        'echo' => false,
        'container' => false,
        'theme_location' => 'main',
        'fallback_cb'=> 'fall_back_menu'
    );

    $menu = wp_nav_menu($options);
    echo preg_replace(array(
        '#^<ul[^>]*>#',
        '#</ul>$#'
    ), '', $menu);

}

function fall_back_menu(){
    return;
}

function new_submenu_class($menu) {    
    $menu = preg_replace('/ class="sub-menu"/','/ class="sub-menu" /',$menu);        
    return $menu;      
}

add_filter('wp_nav_menu','new_submenu_class');

function add_classes_on_li($classes, $item, $args) {
    $classes[] = 'nav-item';
    return $classes;
}
add_filter('nav_menu_css_class','add_classes_on_li',1,3);

function add_menuclass($ulclass) {
   return preg_replace('/<a /', '<a class="nav-links"', $ulclass);
}
add_filter('wp_nav_menu','add_menuclass');

add_action('admin_head', 'my_custom_fonts');
function my_custom_fonts() {
  echo '<style>
    .notice-error{display:none}
  </style>';
}


add_filter('xmlrpc_enabled', '__return_false');

function wpse_11826_search_by_title( $search, $wp_query ) {
    if ( ! empty( $search ) && ! empty( $wp_query->query_vars['search_terms'] ) ) {
        global $wpdb;

        $q = $wp_query->query_vars;
        $n = ! empty( $q['exact'] ) ? '' : '%';

        $search = array();

        foreach ( ( array ) $q['search_terms'] as $term )
            $search[] = $wpdb->prepare( "$wpdb->posts.post_title LIKE %s", $n . $wpdb->esc_like( $term ) . $n );

        if ( ! is_user_logged_in() )
            $search[] = "$wpdb->posts.post_password = ''";

        $search = ' AND ' . implode( ' AND ', $search );
    }

    return $search;
}

add_filter( 'posts_search', 'wpse_11826_search_by_title', 10, 2 );

//Allow Contributors to Add Media
if ( current_user_can('contributor') && !current_user_can('upload_files') )
add_action('admin_init', 'allow_contributor_uploads');

function allow_contributor_uploads() {
$contributor = get_role('contributor');
$contributor->add_cap('upload_files');
}

//Xóa bỏ /category/ và slug category cha

add_filter('term_link', 'devvn_no_category_parents', 1000, 3);
function devvn_no_category_parents($url, $term, $taxonomy) {
    if($taxonomy == 'category'){
        $term_nicename = $term->slug;
        $url = trailingslashit(get_option( 'home' )) . user_trailingslashit( $term_nicename, 'category' );
    }
    return $url;
}
// Rewrite url mới
function devvn_no_category_parents_rewrite_rules($flash = false) {
    $terms = get_terms( array(
        'taxonomy' => 'category',
        'post_type' => 'post',
        'hide_empty' => false,
    ));
    if($terms && !is_wp_error($terms)){
        foreach ($terms as $term){
            $term_slug = $term->slug;
            add_rewrite_rule($term_slug.'/?$', 'index.php?category_name='.$term_slug,'top');
            add_rewrite_rule($term_slug.'/page/([0-9]{1,})/?$', 'index.php?category_name='.$term_slug.'&paged=$matches[1]','top');
            add_rewrite_rule($term_slug.'/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$', 'index.php?category_name='.$term_slug.'&feed=$matches[1]','top');
        }
    }
    if ($flash == true)
        flush_rewrite_rules(false);
}
add_action('init', 'devvn_no_category_parents_rewrite_rules');
 
/*Sửa lỗi khi tạo mới category bị 404*/
function devvn_new_category_edit_success() {
    devvn_no_category_parents_rewrite_rules(true);
}
add_action('created_category','devvn_new_category_edit_success');
add_action('edited_category','devvn_new_category_edit_success');
add_action('delete_category','devvn_new_category_edit_success');




function cx_archive_link( $paged = true ) {
        $link = false;
        if ( is_front_page() ) {
                $link = home_url( '/' );
        } else if ( is_home() && "page" == get_option('show_on_front') ) {
                $link = get_permalink( get_option( 'page_for_posts' ) );
        } else if ( is_tax() || is_tag() || is_category() ) {
                $term = get_queried_object();
                $link = get_term_link( $term, $term->taxonomy );
        } else if ( is_post_type_archive() ) {
                $link = get_post_type_archive_link( get_post_type() );
        } else if ( is_author() ) {
                $link = get_author_posts_url( get_query_var('author'), get_query_var('author_name') );
        } else if ( is_single() ) {
                $link = get_permalink( $id );
        } else if ( is_archive() ) {
                if ( is_date() ) {
                        if ( is_day() ) {
                                $link = get_day_link( get_query_var('year'), get_query_var('monthnum'), get_query_var('day') );
                        } else if ( is_month() ) {
                                $link = get_month_link( get_query_var('year'), get_query_var('monthnum') );
                        } else if ( is_year() ) {
                                $link = get_year_link( get_query_var('year') );
                        }
                }
        }
        if ( $paged && $link && get_query_var('paged') > 1 ) {
                global $wp_rewrite;
                if ( !$wp_rewrite->using_permalinks() ) {
                        $link = add_query_arg( 'paged', get_query_var('paged'), $link );
                } else {
                        $link = user_trailingslashit( trailingslashit( $link ) . trailingslashit( $wp_rewrite->pagination_base ) . get_query_var('paged'), 'archive' );
                }
        }
        echo '<link rel="canonical" href="'.$link.'"/>';
}
add_action('wp_head', 'cx_archive_link');

define('DISALLOW_FILE_MODS',false);
define('DISALLOW_FILE_EDIT',false);

include_once( get_stylesheet_directory() . '/admin/admin.php' );

?>